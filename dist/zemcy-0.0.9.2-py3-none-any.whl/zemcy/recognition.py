class Recognition():
    def __init__(self, window=None, strg='', color=(0, 255, 0), thickness=1):
        self.window = window
        self.strg = strg
        self.color = color
        self.thickness = thickness